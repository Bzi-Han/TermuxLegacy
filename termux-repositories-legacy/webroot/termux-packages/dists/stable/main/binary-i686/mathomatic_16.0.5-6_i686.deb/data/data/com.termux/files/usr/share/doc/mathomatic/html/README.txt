
This directory contains the complete Mathomatic user documentation in HTML.
Everything in this documentation directory is copyrighted and licensed under
the GNU Free Documentation License version 1.3. The full text of this license
is contained in file "fdl-1.3-standalone.html".

To read or print the Mathomatic user documentation, point your web browser to
the file "index.html". If the PDF documentation was created, it is in the
file "../manual.pdf". This PDF document is made by the htmldoc program by
typing "make pdf" in the parent directory.

When copying the Mathomatic documentation, please copy this entire directory,
not just selected HTML files from it.

To view online the most recent documentation, visit
http://mathomatic.org/math/doc/ with your web browser.
