-- Copyright 2010-2017 Martin Morawetz. See LICENSE.
-- ChucK LPeg lexer.

local l = require('lexer')
local token, word_match = l.token, l.word_match
local P, R, S = lpeg.P, lpeg.R, lpeg.S

local M = {_NAME = 'chuck'}

-- Whitespace.
local ws = token(l.WHITESPACE, l.space^1)

-- Comments.
local line_comment = '//' * l.nonnewline_esc^0
local block_comment = '/*' * (l.any - '*/')^0 * P('*/')^-1
local comment = token(l.COMMENT, line_comment + block_comment)

-- Strings.
local sq_str = P('L')^-1 * l.delimited_range("'", true)
local dq_str = P('L')^-1 * l.delimited_range('"', true)
local string = token(l.STRING, sq_str + dq_str)

-- Numbers.
local number = token(l.NUMBER, l.float + l.integer)

-- Constants.
local constant = token(l.CONSTANT, word_match{
  -- special values
  'false', 'maybe', 'me', 'null', 'NULL', 'pi', 'true'
})

-- Special special value.
local now = token('now', P('now'))

-- Times.
local time = token('time', word_match{
  'samp', 'ms', 'second', 'minute', 'hour', 'day', 'week'
})

-- Keywords.
local keyword = token(l.KEYWORD, word_match{
  -- Control structures.
  'break', 'continue', 'else', 'for', 'if', 'repeat', 'return', 'switch',
  'until', 'while',
  -- Other chuck keywords.
  'function', 'fun', 'spork', 'const', 'new'
})

-- Classes.
local class = token(l.CLASS, word_match{
  -- Class keywords.
  'class', 'extends', 'implements', 'interface', 'private', 'protected',
  'public', 'pure', 'super', 'static', 'this'
})

-- Types.
local types = token(l.TYPE, word_match{
  'float', 'int', 'time', 'dur', 'void', 'same'
})

-- Global ugens.
local ugen = token('ugen', word_match{'dac', 'adc', 'blackhole'})

-- Identifiers.
local identifier = token(l.IDENTIFIER, l.word)

-- Operators.
local operator = token(l.OPERATOR, S('+-/*%<>!=^&|?~:;.()[]{}@'))

M._rules = {
  {'whitespace', ws},
  {'string', string},
  {'keyword', keyword},
  {'constant', constant},
  {'type', types},
  {'class', class},
  {'ugen', ugen},
  {'time', time},
  {'now', now},
  {'identifier', identifier},
  {'comment', comment},
  {'number', number},
  {'operator', operator},
}

M._tokenstyles = {
  ugen = l.STYLE_CONSTANT,
  time = l.STYLE_NUMBER,
  now = l.STYLE_CONSTANT..',bold'
}

return M
