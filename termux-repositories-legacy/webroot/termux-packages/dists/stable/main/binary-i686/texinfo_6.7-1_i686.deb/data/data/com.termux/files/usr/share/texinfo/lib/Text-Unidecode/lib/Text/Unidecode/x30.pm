# Time-stamp: "Sat Jul 14 00:27:24 2001 by Automatic Bizooty (__blocks2pm.plx)"
$Text::Unidecode::Char[0x30] = [
' ', qq{, }, qq{. }, qq{"}, qq{[JIS]}, qq{"}, qq{/}, '0', qq{<}, qq{> }, qq{<<}, qq{>> }, qq{[}, qq{] }, qq{\{}, qq{\} },
qq{[(}, qq{)] }, qq{\@}, 'X ', qq{[}, qq{] }, qq{[[}, qq{]] }, qq{((}, qq{)) }, qq{[[}, qq{]] }, qq{~ }, qq{``}, qq{''}, qq{,,},
qq{\@}, '1', '2', '3', '4', '5', '6', '7', '8', '9', "", "", "", "", "", "",
qq{~}, qq{+}, qq{+}, qq{+}, qq{+}, "", qq{\@}, qq{ // }, qq{+10+}, qq{+20+}, qq{+30+}, '[?]', '[?]', '[?]', "", "",
'[?]', 'a', 'a', 'i', 'i', 'u', 'u', 'e', 'e', 'o', 'o', 'ka', 'ga', 'ki', 'gi', 'ku',
'gu', 'ke', 'ge', 'ko', 'go', 'sa', 'za', 'si', 'zi', 'su', 'zu', 'se', 'ze', 'so', 'zo', 'ta',
'da', 'ti', 'di', 'tu', 'tu', 'du', 'te', 'de', 'to', 'do', 'na', 'ni', 'nu', 'ne', 'no', 'ha',
'ba', 'pa', 'hi', 'bi', 'pi', 'hu', 'bu', 'pu', 'he', 'be', 'pe', 'ho', 'bo', 'po', 'ma', 'mi',
'mu', 'me', 'mo', 'ya', 'ya', 'yu', 'yu', 'yo', 'yo', 'ra', 'ri', 'ru', 're', 'ro', 'wa', 'wa',
'wi', 'we', 'wo', 'n', 'vu', '[?]', '[?]', '[?]', '[?]', "", "", "", "", qq{"}, qq{"}, '[?]',
'[?]', 'a', 'a', 'i', 'i', 'u', 'u', 'e', 'e', 'o', 'o', 'ka', 'ga', 'ki', 'gi', 'ku',
'gu', 'ke', 'ge', 'ko', 'go', 'sa', 'za', 'si', 'zi', 'su', 'zu', 'se', 'ze', 'so', 'zo', 'ta',
'da', 'ti', 'di', 'tu', 'tu', 'du', 'te', 'de', 'to', 'do', 'na', 'ni', 'nu', 'ne', 'no', 'ha',
'ba', 'pa', 'hi', 'bi', 'pi', 'hu', 'bu', 'pu', 'he', 'be', 'pe', 'ho', 'bo', 'po', 'ma', 'mi',
'mu', 'me', 'mo', 'ya', 'ya', 'yu', 'yu', 'yo', 'yo', 'ra', 'ri', 'ru', 're', 'ro', 'wa', 'wa',
'wi', 'we', 'wo', 'n', 'vu', 'ka', 'ke', 'va', 'vi', 've', 'vo', "", "", qq{"}, qq{"},
];
1;
