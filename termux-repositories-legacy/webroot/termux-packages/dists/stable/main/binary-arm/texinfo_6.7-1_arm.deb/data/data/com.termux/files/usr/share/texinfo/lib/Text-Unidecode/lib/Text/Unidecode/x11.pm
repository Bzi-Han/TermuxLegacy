# Time-stamp: "Sat Jul 14 00:27:21 2001 by Automatic Bizooty (__blocks2pm.plx)"
$Text::Unidecode::Char[0x11] = [
'g', 'gg', 'n', 'd', 'dd', 'r', 'm', 'b', 'bb', 's', 'ss', "", 'j', 'jj', 'c', 'k',
't', 'p', 'h', 'ng', 'nn', 'nd', 'nb', 'dg', 'rn', 'rr', 'rh', 'rN', 'mb', 'mN', 'bg', 'bn',
"", 'bs', 'bsg', 'bst', 'bsb', 'bss', 'bsj', 'bj', 'bc', 'bt', 'bp', 'bN', 'bbN', 'sg', 'sn', 'sd',
'sr', 'sm', 'sb', 'sbg', 'sss', 's', 'sj', 'sc', 'sk', 'st', 'sp', 'sh', "", "", "", "",
'Z', 'g', 'd', 'm', 'b', 's', 'Z', "", 'j', 'c', 't', 'p', 'N', 'j', "", "",
"", "", 'ck', 'ch', "", "", 'pb', 'pN', 'hh', 'Q', '[?]', '[?]', '[?]', '[?]', '[?]', "",
"", 'a', 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa', 'wae', 'oe', 'yo', 'u', 'weo',
'we', 'wi', 'yu', 'eu', 'yi', 'i', qq{a-o}, qq{a-u}, qq{ya-o}, qq{ya-yo}, qq{eo-o}, qq{eo-u}, qq{eo-eu}, qq{yeo-o}, qq{yeo-u}, qq{o-eo},
qq{o-e}, qq{o-ye}, qq{o-o}, qq{o-u}, qq{yo-ya}, qq{yo-yae}, qq{yo-yeo}, qq{yo-o}, qq{yo-i}, qq{u-a}, qq{u-ae}, qq{u-eo-eu}, qq{u-ye}, qq{u-u}, qq{yu-a}, qq{yu-eo},
qq{yu-e}, qq{yu-yeo}, qq{yu-ye}, qq{yu-u}, qq{yu-i}, qq{eu-u}, qq{eu-eu}, qq{yi-u}, qq{i-a}, qq{i-ya}, qq{i-o}, qq{i-u}, qq{i-eu}, qq{i-U}, 'U', qq{U-eo},
qq{U-u}, qq{U-i}, 'UU', '[?]', '[?]', '[?]', '[?]', '[?]', 'g', 'gg', 'gs', 'n', 'nj', 'nh', 'd', 'l',
'lg', 'lm', 'lb', 'ls', 'lt', 'lp', 'lh', 'm', 'b', 'bs', 's', 'ss', 'ng', 'j', 'c', 'k',
't', 'p', 'h', 'gl', 'gsg', 'ng', 'nd', 'ns', 'nZ', 'nt', 'dg', 'tl', 'lgs', 'ln', 'ld', 'lth',
'll', 'lmg', 'lms', 'lbs', 'lbh', 'rNp', 'lss', 'lZ', 'lk', 'lQ', 'mg', 'ml', 'mb', 'ms', 'mss', 'mZ',
'mc', 'mh', 'mN', 'bl', 'bp', 'ph', 'pN', 'sg', 'sd', 'sl', 'sb', 'Z', 'g', 'ss', "", 'kh',
'N', 'Ns', 'NZ', 'pb', 'pN', 'hn', 'hl', 'hm', 'hb', 'Q', '[?]', '[?]', '[?]', '[?]', '[?]',
];
1;
